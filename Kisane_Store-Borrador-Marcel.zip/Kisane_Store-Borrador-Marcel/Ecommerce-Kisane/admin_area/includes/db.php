<?php

$con = mysqli_connect("localhost", "root", "Panqueque1594", "ecomm_kisanestore");
